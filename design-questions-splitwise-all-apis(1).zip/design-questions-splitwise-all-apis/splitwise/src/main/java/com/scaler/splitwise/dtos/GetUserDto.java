package com.scaler.splitwise.dtos;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class GetUserDto {
    private String name;
    private String phoneNumber;
}
