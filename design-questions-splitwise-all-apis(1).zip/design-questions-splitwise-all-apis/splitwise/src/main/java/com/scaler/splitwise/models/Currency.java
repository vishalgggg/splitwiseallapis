package com.scaler.splitwise.models;

public enum Currency {
    INR,
    USD,
    GBP
}
