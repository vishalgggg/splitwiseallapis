package com.scaler.splitwise.commands;

public class Commands {

    public static final String REGISTER_USER = "Register";
}
